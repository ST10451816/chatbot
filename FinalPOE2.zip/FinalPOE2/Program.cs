﻿using System;
using System.Collections.Generic;
using System.Speech.Synthesis;

namespace CyberBot
{
    class Program
    {
        static string userName = "";
        static string userInterest = "";
        static SpeechSynthesizer synth = new SpeechSynthesizer();

        static Dictionary<string, List<string>> topicTips = new Dictionary<string, List<string>>()
        {
            { "password", new List<string> {
                "Use at least 12 characters with a mix of uppercase, lowercase, numbers, and symbols.",
                "Don’t reuse passwords across sites. Each account should have a unique password.",
                "Use a password manager to store and generate strong passwords."
            }},
            { "phishing", new List<string> {
                "Phishing is a cyber attack where attackers try to steal your personal information.",
                "Be cautious of emails that urge urgent action, even if they seem to be from trusted sources.",
                "Hover over links before clicking to verify the destination.",
                "Never download attachments from unknown senders."
            }},
            { "privacy", new List<string> {
                "Adjust social media privacy settings to limit what others can see.",
                "Avoid posting sensitive information like your home address or phone number.",
                "Use incognito mode or private browsing when on shared computers."
            }},
        };

        static List<string> positiveWords = new List<string> {
            "excited", "happy", "curious", "interested", "great", "amazing", "positive", "good", "love", "awesome", "fantastic", "eager"
        };

        static List<string> negativeWords = new List<string> {
            "worried", "sad", "confused", "scared", "anxious", "frustrated", "nervous", "bad", "angry", "upset", "depressed", "afraid"
        };

        static void Main(string[] args)
        {
            ShowAsciiArt();
            GreetUser();
            OfferTopics();
            ChatLoop();
        }

        static void ShowAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
   ____            _                  _                 
  / ___|___  _ __ | |_ ___ _ __ _ __ (_)_ __   __ _ ___ 
 | |   / _ \| '_ \| __/ _ \ '__| '_ \| | '_ \ / _` / __|
 | |__| (_) | | | | ||  __/ |  | | | | | | | | (_| \__ \
  \____\___/|_| |_|\__\___|_|  |_| |_|_|_| |_|\__, |___/
                                               |___/     
");
            Console.ResetColor();
        }

        static void GreetUser()
        {
            Console.WriteLine("Hello! Welcome to the Cybersecurity Awareness Bot.");
            synth.Speak("Welcome to the Cybersecurity Awareness Bot.");

            Console.Write("Before we begin, what's your name? ");
            userName = Console.ReadLine();

            Console.WriteLine($"Nice to meet you, {userName}! I'm here to help you learn about staying safe online.");
            synth.Speak($"Nice to meet you, {userName}.");
        }

        static void OfferTopics()
        {
            Console.WriteLine("\nHere are some cybersecurity topics you can learn about:");
            Console.WriteLine("1. Password Security");
            Console.WriteLine("2. Phishing Scams");
            Console.WriteLine("3. Online Privacy");
            Console.WriteLine("Ask me about any of these topics or just type 'tips' to get started.");
        }

        static void ChatLoop()
        {
            while (true)
            {
                Console.Write($"\n{userName}: ");
                string input = Console.ReadLine().ToLower();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Bot: Could you please type something?");
                    continue;
                }

                AnalyzeSentiment(input);
                DetectInterest(input);

                if (input.Contains("tips"))
                {
                    RespondWithTips("password");
                    RespondWithOnlineSafetyTips();
                }
                else if (input.Contains("password"))
                {
                    RespondWithTips("password");
                }
                else if (input.Contains("phishing"))
                {
                    RespondWithTips("phishing");
                }
                else if (input.Contains("privacy"))
                {
                    RespondWithTips("privacy");
                }
                else if (input.Contains("remember me"))
                {
                    if (!string.IsNullOrEmpty(userInterest))
                    {
                        Console.WriteLine($"Bot: Your name is {userName}, and you're interested in {userInterest}.");
                        synth.Speak($"You're interested in {userInterest}.");
                    }
                    else
                    {
                        Console.WriteLine("Bot: I don't know what you're interested in yet.");
                        synth.Speak("I don't know your interest yet.");
                    }
                }
                else if (input == "exit" || input == "quit")
                {
                    Console.WriteLine("Bot: Goodbye! Stay safe online!");
                    synth.Speak("Goodbye! Stay safe online.");
                    break;
                }
                else
                {
                    Console.WriteLine("Bot: That's an interesting question. Here's a general cybersecurity tip:");
                    GiveRandomGeneralTip();
                }
            }
        }

        static void RespondWithTips(string topic)
        {
            var tips = topicTips[topic];
            var tip = tips[new Random().Next(tips.Count)];
            Console.WriteLine("Bot: " + tip);
            synth.Speak(tip);
        }

        static void RespondWithOnlineSafetyTips()
        {
            var onlineSafetyTips = new List<string>
            {
                "Always use two-factor authentication (2FA) for extra security.",
                "Keep your software and operating system updated to patch vulnerabilities.",
                "Don’t use public Wi-Fi to log in to banking or email accounts.",
                "Install antivirus software and keep it up to date.",
                "Be cautious of links and pop-ups asking for your credentials."
            };

            Console.WriteLine("Bot: Here are some online safety tips:");
            foreach (var tip in onlineSafetyTips)
            {
                Console.WriteLine("- " + tip);
                synth.Speak(tip);
            }
        }

        static void AnalyzeSentiment(string input)
        {
            foreach (var word in negativeWords)
            {
                if (input.Contains(word))
                {
                    Console.WriteLine("Bot: You seem unsure — don’t worry, I'm here to help you learn safely.");
                    synth.Speak("You seem unsure, but I’m here to help.");
                    return;
                }
            }

            foreach (var word in positiveWords)
            {
                if (input.Contains(word))
                {
                    Console.WriteLine("Bot: Awesome! Let’s explore more about cybersecurity.");
                    synth.Speak("Awesome! Let's keep learning about cybersecurity.");
                    return;
                }
            }
        }

        static void DetectInterest(string input)
        {
            if (input.Contains("interested in"))
            {
                int start = input.IndexOf("interested in") + "interested in".Length;
                userInterest = input.Substring(start).Trim();
                Console.WriteLine($"Bot: Got it! You're interested in {userInterest}.");
                synth.Speak($"I’ll remember that you’re interested in {userInterest}.");
            }
        }

        static void GiveRandomGeneralTip()
        {
            var tips = new List<string>
            {
                "Update your software and operating system regularly.",
                "Enable firewalls and antivirus protection.",
                "Use encrypted connections — look for https in URLs.",
                "Don’t share personal information on unknown websites."
            };

            var tip = tips[new Random().Next(tips.Count)];
            Console.WriteLine("Bot: " + tip);
            synth.Speak(tip);
        }
    }
}
